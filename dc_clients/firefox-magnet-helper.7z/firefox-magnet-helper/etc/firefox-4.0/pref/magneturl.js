pref("network.protocol-handler.app.magnet","/usr/bin/magneturl");
pref("network.protocol-handler.warn-external.magnet",false);
pref("network.protocol-handler.app.magnet+http","/usr/bin/magneturl");
pref("network.protocol-handler.warn-external.magnet+http",false);
pref("network.protocol-handler.expose.magnet",true);
